import React from 'react';
import ProductCard from '../components/ProductCard';

export default function Catalog() {
  const dummyProducts = [
    { id: 1, name: 'Producto 1', price: 10000 },
    { id: 2, name: 'Producto 2', price: 15000 },
    { id: 3, name: 'Producto 3', price: 20000 },
    { id: 4, name: 'Producto 4', price: 25000 },
  ];

  return (
    <div style={{ display: 'flex', gap: '20px', padding: '20px' }}>
      {/* Barra Lateral de Filtros */}
      <aside style={{ width: '200px', borderRight: '1px solid #ddd', paddingRight: '15px' }}>
        <h3>Filtros</h3>
        <div>
          <h4>Categoría</h4>
          <label><input type="checkbox" /> Opción A</label><br />
          <label><input type="checkbox" /> Opción B</label>
        </div>
        <div style={{ marginTop: '15px' }}>
          <h4>Precio</h4>
          <input type="range" />
        </div>
      </aside>

      {/* Grilla Principal */}
      <main style={{ flex: 1 }}>
        <h2>Catálogo de Productos</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: '15px', marginTop: '15px' }}>
          {dummyProducts.map((p) => (
            <ProductCard key={p.id} title={p.name} price={p.price} />
          ))}
        </div>
      </main>
    </div>
  );
}