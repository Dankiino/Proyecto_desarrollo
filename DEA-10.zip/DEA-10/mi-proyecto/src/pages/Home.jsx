import React from 'react';

export default function Home() {
  return (
    <div style={{ padding: '20px' }}>
      {/* Hero Banner */}
      <section style={{ background: '#f0f0f0', padding: '40px', borderRadius: '8px', textAlign: 'center', marginBottom: '20px', color: '#333' }}>
        <h1>Bienvenido a Nuestra Tienda</h1>
        <p>Encuentra los mejores productos al mejor precio.</p>
      </section>

      {/* Categorías Destacadas */}
      <section>
        <h2>Categorías Destacadas</h2>
        <div style={{ display: 'flex', gap: '15px', marginTop: '10px' }}>
          <div style={{ border: '1px solid #ccc', padding: '15px', borderRadius: '5px', flex: 1 }}>Categoría 1</div>
          <div style={{ border: '1px solid #ccc', padding: '15px', borderRadius: '5px', flex: 1 }}>Categoría 2</div>
          <div style={{ border: '1px solid #ccc', padding: '15px', borderRadius: '5px', flex: 1 }}>Categoría 3</div>
        </div>
      </section>
    </div>
  );
}