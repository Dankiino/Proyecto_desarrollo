import React from 'react';

export default function ProductCard({ title, price }) {
  return (
    <div style={{ border: '1px solid #ddd', padding: '15px', borderRadius: '8px', textAlign: 'center' }}>
      <div style={{ width: '100%', height: '120px', background: '#eee', marginBottom: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        [Imagen]
      </div>
      <h3>{title}</h3>
      <p><strong>${price}</strong></p>
      <button>Ver Producto</button>
    </div>
  );
}