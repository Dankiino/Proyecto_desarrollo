import React, { useState } from 'react';
import Home from './pages/Home';
import Catalog from './pages/Catalog';

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');

  return (
    <div>
      {/* Barra de Navegación Simple */}
      <nav style={{ padding: '15px', background: '#333', color: '#fff', display: 'flex', gap: '15px' }}>
        <button 
          onClick={() => setCurrentPage('home')}
          style={{ padding: '8px 12px', cursor: 'pointer', background: currentPage === 'home' ? '#555' : '#222', color: '#fff', border: 'none', borderRadius: '4px' }}
        >
          Inicio
        </button>
        <button 
          onClick={() => setCurrentPage('catalog')}
          style={{ padding: '8px 12px', cursor: 'pointer', background: currentPage === 'catalog' ? '#555' : '#222', color: '#fff', border: 'none', borderRadius: '4px' }}
        >
          Catálogo
        </button>
      </nav>

      {/* Renderizado Condicional */}
      {currentPage === 'home' && <Home />}
      {currentPage === 'catalog' && <Catalog />}
    </div>
  );
}